from django.conf.urls import url
from . import views
from django.views.generic import View

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^list/$', views.list, name='list'),
    url(r'^(?P<question_id>[0-9]+)/$', views.post, name='post'),
    # ex: /polls/5/results/
    url(r'^(?P<question_id>[0-9]+)/sentence/(?P<sent_id>[0-9]+)$', views.results, name='sentence'),
    # ex: /polls/5/vote/
    url(r'^(?P<question_id>[0-9]+)/vote/$', views.vote, name='vote'),
]
