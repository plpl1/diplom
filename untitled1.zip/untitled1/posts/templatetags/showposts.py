from django import template
from posts.models import *
import time

register = template.Library()

@register.simple_tag
def get_date(unixdate):
    date = time.asctime(time.localtime(unixdate))
    format_date = time.strptime(date, "%a %b %d %H:%M:%S %Y")
    date_f = time.strftime("%d-%m-%Y. %H:%M:%S", format_date)
    return date_f

@register.simple_tag
def get_sentences_count(p_id):
    count = Sentence.objects.filter(post_id=p_id).count()
    return count

@register.simple_tag
def get_words_count(p_id):
    count = 0
    sent = Sentence.objects.filter(post_id=p_id)
    for w in sent:
        count += Word.objects.filter(sentence_id=w.id).count()
    return count



@register.inclusion_tag('posts/sentences.html')
def get_sent(p_id):
    sents = Sentence.objects.filter(post_id=p_id)
    return {'sents': sents}


@register.inclusion_tag('posts/words.html')
def get_word(s_id):
    words = Word.objects.filter(sentence_id=s_id)
    return {'words': words}


@register.inclusion_tag('posts/pop_word.html')
def get_morph(w_id):
    pop = Word.objects.get(id=w_id)
    return {'pop': pop}


