from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from .models import Post
from .forms import MyForm
from django.shortcuts import render, get_object_or_404
from django.views.generic import View
from posts.mind import parse
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


# TODO добавлять только уникальные посты
def index(request):
    # if this is a POST request we need to process the form data
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = MyForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            id = form.cleaned_data.get('user_id')
            count = form.cleaned_data.get('count')
            data = parse.parse(id, count)  # TODO переиименовать переменные
            return HttpResponse(data)
    # if a GET (or any other method) we'll create a blank form
    else:
        form = MyForm()

    return render(request, 'posts/index.html', {'form': form})


def list(request):
    post_list = Post.objects.all().order_by('-id')
    paginator = Paginator(post_list, 5)  # Show 5 contacts per page
    page = request.GET.get('page')
    try:
        posts = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        posts = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        posts = paginator.page(paginator.num_pages)

    return render(request, 'posts/list.html', {'posts': posts})


def post(request, question_id):

    if request.method == 'GET':
        emotion = request.GET.get('emotion')
        if emotion:
            t = Post.objects.get(pk=question_id)
            t.status = 2
            t.emotion = emotion
            t.save()
            if emotion == '1':
                adddic.pos()

    post_data = get_object_or_404(Post, pk=question_id)
    return render(request, 'posts/post.html', {'post_data': post_data})


def results(request, question_id):
    response = "You're looking at the results of question %s."
    return HttpResponse(response % question_id)


def vote(request, question_id):
    return HttpResponse("You're voting on question %s." % question_id)

def button_pos(request):
    return HttpResponse("You're voting on question %s." %request)


