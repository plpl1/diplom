from django import forms

C = [i for i in range(0, 100)]


class MyForm(forms.Form):
    user_id = forms.CharField(min_length=3, max_length=100, label="Введите поисковый запрос")
    count = forms.IntegerField(max_value=100, label="Введите количество постов")  #TODO Сделать выпадающим списком widget=forms.Select(choices=C)

