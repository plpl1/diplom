# -*- coding:utf-8 -*
import nltk
import math
from nltk.corpus import stopwords
import pymorphy2
from posts.mind import vk_parse
from posts.models import Post, Sentence, Word
from django.utils import timezone
import time
morph = pymorphy2.MorphAnalyzer()


def parse(uid, count):

    posts = vk_parse.getsearch(uid, count)
    add_count = 0
    # парсим посты
    for post in posts:
        post_type = 'vk'
        post_id = post['id']
        text = post['text']
        datepub = post['date']
        likes = post['likes']['count']
        #  views = post['views']['count']  - пока нет в VK API
        author_id = post['from_id']
        if text:
            if not Post.objects.filter(vk_post_id=post_id, author_id=author_id).exists():
                p = Post(text=text, emotion='0', datePub=datepub, dateIn=time.time(), likes=likes, views=0,
                         author_id=author_id, vk_post_id=post_id, post_type=post_type)
                p.save()
                add_count += 1
                sent = nltk.sent_tokenize(text)  # разделяем текст на предложения
                for i in range(len(sent)):  # для каждого предложения
                    s = Sentence.objects.create(text=sent[i], emotion='0', post_id=p.pk)
                    s.save()
                    token = nltk.word_tokenize(sent[i])  # выделяем токены
                    for word in token:  # для каждого токена
                        w = Word.objects.create(text=word, morph=morph.parse(word)[0].tag, emotion='0', sentence_id=s.pk)
                        w.save()
    return add_count

# tagpost - tagpost[№ поста(p)][№ предложения(s)][№ лексемы(l)][0 - лексема, 1 - морфологические данные, 2 - тональность]


# Добавляем в словарь лексемы ltype - тип добавления (posts - несколько постов, post - один пост, sent - предложение, word - слово)

#file = open('words.csv','wb')
#wrtr = csv.writer(file)
#for sentence in tokens:
 #   for words in sentence:
  #      wordtag = morph.parse(words)[0].word
   #     tag = morph.parse(words)[0].tag