from posts.mind import vk_parse
from posts.models import Post, Sentence, Word, PosDict, NegDict
from django.utils import timezone
import time

def pos(post_id):
    p = Word.objects.filter(sentence__post_id=post_id)
    for o in p:
        if PosDict.objects.filter(word=o['text']).exists():
            count = PosDict.objects.get(word=o['text'])
            x = PosDict.objects.filter(word=o['text']).update(count=count+1)
