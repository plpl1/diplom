#//ССЫЛКА НА ПРИЛОЖЕНИЕ//https://oauth.vk.com/authorize?client_id=5873096&display=page&redirect_uri=https://oauth.vk.com/blank.htmlk&scope=friends,pages,messages ,wall,offline&response_type=token&v=5.62&state=123456
#//ССЫЛКА НА ТОКЕН//access_token=92c18391093efc7add7bc0cfe3022adec728c15fd532e3f982b5ae21e9a335ee1167e12c0effa6344190b&expires_in=86400&user_id=49208961&state=123456

import vk

APPID = '5873096'
TOKEN = '92c18391093efc7add7bc0cfe3022adec728c15fd532e3f982b5ae21e9a335ee1167e12c0effa6344190b'
LOGIN = '+79158367697'
token = vk.access_token = TOKEN
session = vk.Session(token)
vkapi = vk.API(session)


def getwall(id, count):
    posts = vkapi.wall.get(owner_id=id, count=count)[1:]
    return posts


def getsearch(q, count):
    posts = vkapi.newsfeed.search(q=q, count=count)[1:]
    return posts
