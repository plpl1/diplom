from django.db import models


class Post(models.Model):
    post_type = models.CharField(max_length=20, default='prog')
    text = models.CharField(max_length=5000)
    vk_post_id = models.IntegerField(null=True)
    author_id = models.IntegerField(null=True)
    datePub = models.IntegerField(null=True)
    dateIn = models.IntegerField(null=True)
    emotion = models.IntegerField(null=True)
    status = models.PositiveIntegerField(default=0)
    views = models.IntegerField(null=True)
    likes = models.IntegerField(null=True)

    def __str__(self):
        return self.text[:15]


class Sentence(models.Model):
    post = models.ForeignKey(Post)
    text = models.CharField(max_length=1000)
    emotion = models.IntegerField(null=True)

    def __str__(self):
        return self.text[:15]


class Word(models.Model):
    sentence = models.ForeignKey(Sentence)
    text = models.CharField(max_length=200)
    morph = models.CharField(max_length=200)
    emotion = models.IntegerField(null=True)

    def __str__(self):
        return self.text[:15]


class PosDict(models.Model):
    word = models.CharField(max_length=200)
    morph = models.CharField(max_length=200)
    count = models.PositiveIntegerField(default=1)


class NegDict(models.Model):
    word = models.CharField(max_length=200)
    morph = models.CharField(max_length=200)
    count = models.PositiveIntegerField(default=1)


