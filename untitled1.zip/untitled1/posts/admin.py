from django.contrib import admin
from .models import Post
from .models import Sentence
from .models import Word


admin.site.register(Post)
admin.site.register(Sentence)
admin.site.register(Word)

# Register your models here.
